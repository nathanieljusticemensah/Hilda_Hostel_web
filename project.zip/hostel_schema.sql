-- ============================================================
-- Hostel Operations & Utility Portal — Production Schema
-- Fixes applied vs. dev draft:
--   1. Real role-based RLS (no more USING (true) everywhere)
--   2. booking_phase global state machine (system_settings table)
--   3. room_availability view (capacity - confirmed allocations)
--   4. Concurrency-safe booking via SECURITY DEFINER function + row locking
--   5. announcements.category to match SRS, updated_at triggers
--   6. Indexes on foreign keys, applicant role scoped
-- ============================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================
-- 1. CUSTOM ENUMS
-- ============================================================
CREATE TYPE user_role AS ENUM ('admin', 'staff', 'resident', 'applicant');
CREATE TYPE utility_type AS ENUM ('water', 'power');
CREATE TYPE room_tier AS ENUM ('1_in_room', '2_in_room', '3_in_room', '4_in_room');
CREATE TYPE ticket_category AS ENUM ('plumbing', 'electrical', 'carpentry', 'masonry', 'noise_complaint', 'other');
CREATE TYPE ticket_priority AS ENUM ('low', 'medium', 'urgent');
CREATE TYPE ticket_status AS ENUM ('open', 'in_progress', 'resolved', 'cancelled');
CREATE TYPE allocation_status AS ENUM ('retention_requested', 'reserved', 'confirmed', 'rejected');
CREATE TYPE booking_phase AS ENUM ('closed', 'retention_only', 'open_booking');

-- ============================================================
-- 2. PROFILES TABLE (Syncs with Supabase Auth)
-- ============================================================
CREATE TABLE public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    full_name TEXT NOT NULL DEFAULT '',
    phone_number TEXT DEFAULT '',
    role user_role DEFAULT 'resident',
    room_id UUID,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_profiles_room_id ON public.profiles(room_id);
CREATE INDEX idx_profiles_role ON public.profiles(role);

-- ============================================================
-- 3. ROOMS TABLE
-- ============================================================
CREATE TABLE public.rooms (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    room_number TEXT UNIQUE NOT NULL,
    block TEXT NOT NULL,
    floor INT NOT NULL,
    tier room_tier NOT NULL,
    capacity INT NOT NULL CHECK (capacity > 0),
    price_per_academic_year NUMERIC(10, 2) NOT NULL,
    images TEXT[] DEFAULT '{}',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.profiles
ADD CONSTRAINT fk_profiles_room FOREIGN KEY (room_id) REFERENCES public.rooms(id) ON DELETE SET NULL;

-- ============================================================
-- 4. UTILITIES TABLE (Water & Power)
-- ============================================================
CREATE TABLE public.utilities (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    type utility_type UNIQUE NOT NULL,
    status TEXT NOT NULL,
    schedule_note TEXT,
    estimated_end_time TIMESTAMPTZ,
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    updated_by UUID REFERENCES public.profiles(id)
);

INSERT INTO public.utilities (type, status, schedule_note)
VALUES
    ('water', 'dry', 'Pumping scheduled at 6:00 AM'),
    ('power', 'grid', 'Running on national grid')
ON CONFLICT (type) DO NOTHING;

-- ============================================================
-- 5. SYSTEM SETTINGS (Booking Phase State Machine)
-- Single-row config table the admin controls; broadcast via Realtime
-- so clients can react to phase changes instantly.
-- ============================================================
CREATE TABLE public.system_settings (
    id INT PRIMARY KEY DEFAULT 1 CHECK (id = 1), -- enforce single row
    current_booking_phase booking_phase NOT NULL DEFAULT 'closed',
    active_academic_year TEXT NOT NULL DEFAULT '2026/2027',
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    updated_by UUID REFERENCES public.profiles(id)
);

INSERT INTO public.system_settings (id, current_booking_phase, active_academic_year)
VALUES (1, 'closed', '2026/2027')
ON CONFLICT (id) DO NOTHING;

-- ============================================================
-- 6. ROOM ALLOCATIONS & RETENTION
-- ============================================================
CREATE TABLE public.room_allocations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    room_id UUID NOT NULL REFERENCES public.rooms(id) ON DELETE CASCADE,
    student_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    academic_year TEXT NOT NULL,
    status allocation_status DEFAULT 'retention_requested',
    is_retention BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(student_id, academic_year)
);

CREATE INDEX idx_allocations_room_id ON public.room_allocations(room_id);
CREATE INDEX idx_allocations_student_id ON public.room_allocations(student_id);
CREATE INDEX idx_allocations_status ON public.room_allocations(status);

-- ============================================================
-- 7. MAINTENANCE TICKETS & COMPLAINTS
-- ============================================================
CREATE TABLE public.maintenance_tickets (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    room_id UUID REFERENCES public.rooms(id) ON DELETE SET NULL,
    student_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    category ticket_category NOT NULL,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    image_url TEXT,
    image_file_id TEXT,
    priority ticket_priority DEFAULT 'medium',
    status ticket_status DEFAULT 'open',
    resolution_note TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    resolved_at TIMESTAMPTZ
);

CREATE INDEX idx_tickets_room_id ON public.maintenance_tickets(room_id);
CREATE INDEX idx_tickets_student_id ON public.maintenance_tickets(student_id);
CREATE INDEX idx_tickets_status ON public.maintenance_tickets(status);

-- ============================================================
-- 8. ANNOUNCEMENTS & EMERGENCY CONTACTS
-- (category added to match SRS Section 5; priority kept for urgency badges)
-- ============================================================
CREATE TABLE public.announcements (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    category TEXT DEFAULT 'general',
    priority TEXT DEFAULT 'general',
    image_url TEXT,
    is_pinned BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_announcements_pinned_created ON public.announcements(is_pinned DESC, created_at DESC);

-- ============================================================
-- 9. AUTOMATIC PROFILE CREATION TRIGGER
-- ============================================================
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, phone_number, role)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', 'Hostel Resident'),
    COALESCE(NEW.raw_user_meta_data->>'phone_number', ''),
    'resident'
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ============================================================
-- 10. updated_at AUTO-TOUCH TRIGGERS
-- ============================================================
CREATE OR REPLACE FUNCTION public.touch_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_utilities_touch
  BEFORE UPDATE ON public.utilities
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE TRIGGER trg_settings_touch
  BEFORE UPDATE ON public.system_settings
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- ============================================================
-- 11. ROLE-CHECK HELPER FUNCTIONS (SECURITY DEFINER)
-- These read profiles.role without recursive RLS evaluation issues.
-- ============================================================
CREATE OR REPLACE FUNCTION public.current_user_role()
RETURNS user_role AS $$
  SELECT role FROM public.profiles WHERE id = auth.uid();
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public;

CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN AS $$
  SELECT public.current_user_role() = 'admin';
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public;

CREATE OR REPLACE FUNCTION public.is_staff_or_admin()
RETURNS BOOLEAN AS $$
  SELECT public.current_user_role() IN ('staff', 'admin');
$$ LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public;

-- ============================================================
-- 12. ROOM AVAILABILITY VIEW
-- Available Beds = Capacity - Count(Confirmed Allocations for that year)
-- Parameterized by academic_year via a function wrapper (views can't
-- take params, so expose both a function and a "current year" view).
-- ============================================================
CREATE OR REPLACE FUNCTION public.room_availability(p_academic_year TEXT)
RETURNS TABLE (
    room_id UUID,
    room_number TEXT,
    block TEXT,
    floor INT,
    tier room_tier,
    capacity INT,
    price_per_academic_year NUMERIC,
    confirmed_count BIGINT,
    available_beds INT
) AS $$
  SELECT
    r.id,
    r.room_number,
    r.block,
    r.floor,
    r.tier,
    r.capacity,
    r.price_per_academic_year,
    COALESCE(a.confirmed_count, 0) AS confirmed_count,
    r.capacity - COALESCE(a.confirmed_count, 0)::INT AS available_beds
  FROM public.rooms r
  LEFT JOIN (
    -- Holds a bed for 'confirmed' and 'reserved' allocations, but not
    -- raw 'retention_requested' — an unresolved request shouldn't
    -- indefinitely hide a bed from the public count. This still closes
    -- the race window: book_room() only runs during open_booking, which
    -- should only start after retention requests are resolved.
    SELECT room_id, COUNT(*) AS confirmed_count
    FROM public.room_allocations
    WHERE academic_year = p_academic_year AND status IN ('confirmed', 'reserved')
    GROUP BY room_id
  ) a ON a.room_id = r.id
  WHERE r.is_active = TRUE;
$$ LANGUAGE sql STABLE;

-- Convenience view: availability for whatever year is currently active
CREATE OR REPLACE VIEW public.room_availability_current AS
SELECT ra.*
FROM public.room_availability(
  (SELECT active_academic_year FROM public.system_settings WHERE id = 1)
) ra;

-- ============================================================
-- 13. CONCURRENCY-SAFE BOOKING FUNCTION
-- Handles the "last bed" race condition with row-level locking.
-- Client calls this RPC instead of inserting into room_allocations
-- directly during open_booking phase.
-- ============================================================
CREATE OR REPLACE FUNCTION public.book_room(p_room_id UUID, p_academic_year TEXT)
RETURNS public.room_allocations AS $$
DECLARE
  v_capacity INT;
  v_confirmed_count INT;
  v_phase booking_phase;
  v_allocation public.room_allocations;
BEGIN
  SELECT current_booking_phase INTO v_phase FROM public.system_settings WHERE id = 1;
  IF v_phase != 'open_booking' THEN
    RAISE EXCEPTION 'Booking is not currently open (phase: %)', v_phase;
  END IF;

  -- Lock the room row for the duration of this transaction so two
  -- concurrent bookings can't both read "1 bed left" and both succeed.
  SELECT capacity INTO v_capacity
  FROM public.rooms
  WHERE id = p_room_id AND is_active = TRUE
  FOR UPDATE;

  IF v_capacity IS NULL THEN
    RAISE EXCEPTION 'Room not found or inactive';
  END IF;

  SELECT COUNT(*) INTO v_confirmed_count
  FROM public.room_allocations
  WHERE room_id = p_room_id
    AND academic_year = p_academic_year
    AND status = 'confirmed';

  IF v_confirmed_count >= v_capacity THEN
    RAISE EXCEPTION 'Room is fully booked';
  END IF;

  INSERT INTO public.room_allocations (room_id, student_id, academic_year, status, is_retention)
  VALUES (p_room_id, auth.uid(), p_academic_year, 'confirmed', FALSE)
  ON CONFLICT (student_id, academic_year)
  DO UPDATE SET room_id = EXCLUDED.room_id, status = 'confirmed'
  RETURNING * INTO v_allocation;

  RETURN v_allocation;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- ============================================================
-- 14. ENABLE ROW LEVEL SECURITY (RLS)
-- ============================================================
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.utilities ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.system_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.room_allocations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.maintenance_tickets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;

-- ============================================================
-- 15. PRODUCTION RLS POLICIES (role-enforced)
-- ============================================================

-- Profiles: everyone can view (needed for directory/UI), only self or
-- admin can update; role changes restricted to admin only.
CREATE POLICY "Profiles viewable by everyone" ON public.profiles
  FOR SELECT USING (true);

CREATE POLICY "Users update own non-role fields" ON public.profiles
  FOR UPDATE USING (auth.uid() = id)
  WITH CHECK (
    auth.uid() = id
    AND role = public.current_user_role()
  );

CREATE POLICY "Admin manages all profiles" ON public.profiles
  FOR UPDATE USING (public.is_admin());

-- Utilities: everyone reads; only staff/admin can update status.
CREATE POLICY "Utilities viewable by everyone" ON public.utilities
  FOR SELECT USING (true);

CREATE POLICY "Staff or admin update utilities" ON public.utilities
  FOR UPDATE USING (public.is_staff_or_admin());

-- System settings: everyone reads (client needs booking_phase to render
-- the right UI); only admin can change the phase.
CREATE POLICY "Settings viewable by everyone" ON public.system_settings
  FOR SELECT USING (true);

CREATE POLICY "Admin updates settings" ON public.system_settings
  FOR UPDATE USING (public.is_admin());

-- Rooms: everyone reads (public catalog); only admin manages inventory.
CREATE POLICY "Rooms viewable by everyone" ON public.rooms
  FOR SELECT USING (true);

CREATE POLICY "Admin manages rooms" ON public.rooms
  FOR ALL USING (public.is_admin());

-- Allocations: students see only their own; staff/admin see all.
-- Direct inserts allowed for retention flow (retention_only phase);
-- open-booking inserts should go through book_room() to get locking.
CREATE POLICY "Own allocations or staff/admin view all" ON public.room_allocations
  FOR SELECT USING (auth.uid() = student_id OR public.is_staff_or_admin());

CREATE POLICY "Students insert own retention request" ON public.room_allocations
  FOR INSERT WITH CHECK (
    auth.uid() = student_id
    AND (SELECT current_booking_phase FROM public.system_settings WHERE id = 1) = 'retention_only'
  );

CREATE POLICY "Staff or admin update allocations" ON public.room_allocations
  FOR UPDATE USING (public.is_staff_or_admin());

-- Maintenance tickets: students see only their own; staff/admin see all.
CREATE POLICY "Own tickets or staff/admin view all" ON public.maintenance_tickets
  FOR SELECT USING (auth.uid() = student_id OR public.is_staff_or_admin());

CREATE POLICY "Students insert own tickets" ON public.maintenance_tickets
  FOR INSERT WITH CHECK (auth.uid() = student_id);

CREATE POLICY "Staff or admin update tickets" ON public.maintenance_tickets
  FOR UPDATE USING (public.is_staff_or_admin());

-- Students may cancel a ticket they submitted by mistake, but only
-- while it's still open (can't cancel something staff already started)
-- and can only move it to 'cancelled', nothing else.
CREATE POLICY "Students cancel own open tickets" ON public.maintenance_tickets
  FOR UPDATE USING (
    auth.uid() = student_id AND status = 'open'
  )
  WITH CHECK (
    auth.uid() = student_id AND status = 'cancelled'
  );

-- Announcements: everyone reads; only staff/admin manage.
CREATE POLICY "Announcements viewable by everyone" ON public.announcements
  FOR SELECT USING (true);

CREATE POLICY "Staff or admin manage announcements" ON public.announcements
  FOR ALL USING (public.is_staff_or_admin());

-- ============================================================
-- 16. ENABLE REALTIME BROADCASTING
-- ============================================================
ALTER PUBLICATION supabase_realtime ADD TABLE
  public.utilities,
  public.announcements,
  public.maintenance_tickets,
  public.system_settings;